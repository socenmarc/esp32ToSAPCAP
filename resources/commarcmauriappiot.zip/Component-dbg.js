sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("com.marcmauri.app.iot.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
